
appScreen.nextButtonPressed = function() {
		doGetSeatMapRequest(true);
	
}
